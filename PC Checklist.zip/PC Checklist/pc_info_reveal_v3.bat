@echo off
setlocal enabledelayedexpansion
title PC Info Reveal
color 0A

for /f %%i in ('powershell -NoProfile -Command "Get-Date -Format yyyy-MM-dd_HHmmss"') do set "STAMP=%%i"
set "OUTFILE=%USERPROFILE%\Desktop\PC_Info_Report_%STAMP%.txt"

echo Gathering system info... this takes 20-40 seconds.
echo.

echo ============================================ > "%OUTFILE%"
echo   PC INFO REPORT - Generated %date% %time% >> "%OUTFILE%"
echo ============================================ >> "%OUTFILE%"
echo. >> "%OUTFILE%"

echo ---------- OS / SYSTEM ---------- >> "%OUTFILE%"
powershell -NoProfile -Command "$os = Get-CimInstance Win32_OperatingSystem; $cs = Get-CimInstance Win32_ComputerSystem; Write-Output ('Computer Name : ' + $cs.Name); Write-Output ('Manufacturer  : ' + $cs.Manufacturer); Write-Output ('Model         : ' + $cs.Model); Write-Output ('OS            : ' + $os.Caption + ' ' + $os.OSArchitecture); Write-Output ('Build         : ' + $os.BuildNumber); Write-Output ('Install Date  : ' + $os.InstallDate); Write-Output ('Last Boot     : ' + $os.LastBootUpTime)" >> "%OUTFILE%"
echo. >> "%OUTFILE%"

echo ---------- CPU ---------- >> "%OUTFILE%"
powershell -NoProfile -Command "Get-CimInstance Win32_Processor | ForEach-Object { Write-Output ('Name          : ' + $_.Name); Write-Output ('Cores         : ' + $_.NumberOfCores); Write-Output ('Logical Procs : ' + $_.NumberOfLogicalProcessors); Write-Output ('Max Clock     : ' + $_.MaxClockSpeed + ' MHz') }" >> "%OUTFILE%"
echo. >> "%OUTFILE%"

echo ---------- RAM ---------- >> "%OUTFILE%"
powershell -NoProfile -Command "$total = 0; Get-CimInstance Win32_PhysicalMemory | ForEach-Object { $gb = [math]::Round($_.Capacity/1GB,2); $total += $gb; Write-Output ('Stick: ' + $gb + ' GB @ ' + $_.Speed + ' MHz - ' + $_.Manufacturer) }; Write-Output ('TOTAL RAM     : ' + $total + ' GB')" >> "%OUTFILE%"
echo. >> "%OUTFILE%"

echo ---------- STORAGE ---------- >> "%OUTFILE%"
powershell -NoProfile -Command "Get-CimInstance Win32_DiskDrive | ForEach-Object { Write-Output ('Drive: ' + $_.Model + ' - ' + [math]::Round($_.Size/1GB,2) + ' GB - MediaType: ' + $_.MediaType) }" >> "%OUTFILE%"
echo. >> "%OUTFILE%"
echo ---- Free Space per Volume ---- >> "%OUTFILE%"
powershell -NoProfile -Command "Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' | ForEach-Object { Write-Output ($_.DeviceID + '  Free: ' + [math]::Round($_.FreeSpace/1GB,2) + ' GB / Total: ' + [math]::Round($_.Size/1GB,2) + ' GB') }" >> "%OUTFILE%"
echo. >> "%OUTFILE%"

echo ---------- DRIVE HEALTH (SMART) ---------- >> "%OUTFILE%"
powershell -NoProfile -Command "Get-PhysicalDisk | ForEach-Object { $disk = $_; $rel = $_ | Get-StorageReliabilityCounter -ErrorAction SilentlyContinue; Write-Output ('Disk: ' + $disk.FriendlyName); Write-Output ('  HealthStatus     : ' + $disk.HealthStatus); Write-Output ('  OperationalStatus : ' + $disk.OperationalStatus); Write-Output ('  MediaType        : ' + $disk.MediaType); if ($rel) { Write-Output ('  Temperature (C)  : ' + $rel.Temperature); Write-Output ('  PowerOnHours     : ' + $rel.PowerOnHours); Write-Output ('  Wear (SSD %%)     : ' + $rel.Wear); Write-Output ('  ReadErrorsTotal  : ' + $rel.ReadErrorsTotal); Write-Output ('  WriteErrorsTotal : ' + $rel.WriteErrorsTotal) } else { Write-Output '  Reliability counters not available for this drive.' }; Write-Output '' }" >> "%OUTFILE%"
echo NOTE: HealthStatus should say 'Healthy'. Wear near 100%% or high PowerOnHours (30000+) = aging/risky SSD. Any non-zero error counts on an old HDD = red flag. >> "%OUTFILE%"
echo. >> "%OUTFILE%"

echo ---------- GPU ---------- >> "%OUTFILE%"
powershell -NoProfile -Command "Get-CimInstance Win32_VideoController | ForEach-Object { Write-Output ('GPU: ' + $_.Name + ' - Driver: ' + $_.DriverVersion + ' - VRAM: ' + [math]::Round($_.AdapterRAM/1GB,2) + ' GB') }" >> "%OUTFILE%"
echo. >> "%OUTFILE%"

echo ---------- MOTHERBOARD / BIOS ---------- >> "%OUTFILE%"
powershell -NoProfile -Command "$bb = Get-CimInstance Win32_BaseBoard; $bios = Get-CimInstance Win32_BIOS; Write-Output ('Motherboard   : ' + $bb.Manufacturer + ' ' + $bb.Product); Write-Output ('BIOS Version  : ' + $bios.SMBIOSBIOSVersion); Write-Output ('BIOS Date     : ' + $bios.ReleaseDate)" >> "%OUTFILE%"
echo. >> "%OUTFILE%"

echo ---------- BATTERY (laptops only) ---------- >> "%OUTFILE%"
powershell -NoProfile -Command "$bat = Get-CimInstance Win32_Battery; if ($bat) { Write-Output ('Battery       : ' + $bat.Name); Write-Output ('Est. Charge   : ' + $bat.EstimatedChargeRemaining + '%%'); Write-Output ('Status Code   : ' + $bat.BatteryStatus) } else { Write-Output 'No battery detected (desktop).' }" >> "%OUTFILE%"
echo. >> "%OUTFILE%"

echo ---------- NETWORK ---------- >> "%OUTFILE%"
powershell -NoProfile -Command "Get-NetAdapter | Where-Object {$_.Status -eq 'Up'} | ForEach-Object { Write-Output ('Adapter: ' + $_.Name + ' - ' + $_.InterfaceDescription + ' - Link Speed: ' + $_.LinkSpeed) }" >> "%OUTFILE%"
ipconfig | findstr /R /C:"IPv4" /C:"Default Gateway" >> "%OUTFILE%"
echo. >> "%OUTFILE%"

echo ---------- INSTALLED SOFTWARE (top 40, alphabetical) ---------- >> "%OUTFILE%"
powershell -NoProfile -Command "Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*, HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* -ErrorAction SilentlyContinue | Where-Object {$_.DisplayName -ne $null} | Sort-Object DisplayName | Select-Object -First 40 -Property DisplayName, DisplayVersion | Format-Table -AutoSize | Out-String -Width 120" >> "%OUTFILE%"
echo. >> "%OUTFILE%"

echo ---------- WINDOWS ACTIVATION STATUS ---------- >> "%OUTFILE%"
powershell -NoProfile -Command "$s = Get-CimInstance SoftwareLicensingProduct -Filter \"Name like 'Windows%%'\" | Where-Object { $_.PartialProductKey } | Select-Object -First 1 -ExpandProperty LicenseStatus; Write-Output ('License Status Code: ' + $s)" >> "%OUTFILE%"
echo (0=Unlicensed, 1=Licensed/Activated, 2=OOB Grace, 5=Notification) >> "%OUTFILE%"
echo. >> "%OUTFILE%"

echo ============================================ >> "%OUTFILE%"
echo   END OF REPORT >> "%OUTFILE%"
echo ============================================ >> "%OUTFILE%"

echo.
echo Done. Report saved to:
echo %OUTFILE%
echo.
pause
